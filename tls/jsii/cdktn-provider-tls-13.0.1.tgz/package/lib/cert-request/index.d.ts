/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CertRequestConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of DNS names for which a certificate is being requested (i.e. certificate subjects).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#dns_names CertRequest#dns_names}
    */
    readonly dnsNames?: string[];
    /**
    * List of IP addresses for which a certificate is being requested (i.e. certificate subjects).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#ip_addresses CertRequest#ip_addresses}
    */
    readonly ipAddresses?: string[];
    /**
    * Private key in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format, that the certificate will belong to. This can be read from a separate file using the [`file`](https://www.terraform.io/language/functions/file) interpolation function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#private_key_pem CertRequest#private_key_pem}
    */
    readonly privateKeyPem: string;
    /**
    * List of URIs for which a certificate is being requested (i.e. certificate subjects).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#uris CertRequest#uris}
    */
    readonly uris?: string[];
    /**
    * subject block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#subject CertRequest#subject}
    */
    readonly subject?: CertRequestSubject[] | cdktn.IResolvable;
}
export interface CertRequestSubject {
    /**
    * Distinguished name: `CN`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#common_name CertRequest#common_name}
    */
    readonly commonName?: string;
    /**
    * Distinguished name: `C`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#country CertRequest#country}
    */
    readonly country?: string;
    /**
    * ASN.1 Object Identifier (OID): `1.2.840.113549.1.9.1`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#email_address CertRequest#email_address}
    */
    readonly emailAddress?: string;
    /**
    * Distinguished name: `L`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#locality CertRequest#locality}
    */
    readonly locality?: string;
    /**
    * Distinguished name: `O`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#organization CertRequest#organization}
    */
    readonly organization?: string;
    /**
    * Distinguished name: `OU`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#organizational_unit CertRequest#organizational_unit}
    */
    readonly organizationalUnit?: string;
    /**
    * Distinguished name: `PC`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#postal_code CertRequest#postal_code}
    */
    readonly postalCode?: string;
    /**
    * Distinguished name: `ST`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#province CertRequest#province}
    */
    readonly province?: string;
    /**
    * Distinguished name: `SERIALNUMBER`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#serial_number CertRequest#serial_number}
    */
    readonly serialNumber?: string;
    /**
    * Distinguished name: `STREET`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#street_address CertRequest#street_address}
    */
    readonly streetAddress?: string[];
}
export declare function certRequestSubjectToTerraform(struct?: CertRequestSubject | cdktn.IResolvable): any;
export declare function certRequestSubjectToHclTerraform(struct?: CertRequestSubject | cdktn.IResolvable): any;
export declare class CertRequestSubjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CertRequestSubject | cdktn.IResolvable | undefined;
    set internalValue(value: CertRequestSubject | cdktn.IResolvable | undefined);
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    resetCountry(): void;
    get countryInput(): string | undefined;
    private _emailAddress?;
    get emailAddress(): string;
    set emailAddress(value: string);
    resetEmailAddress(): void;
    get emailAddressInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _organizationalUnit?;
    get organizationalUnit(): string;
    set organizationalUnit(value: string);
    resetOrganizationalUnit(): void;
    get organizationalUnitInput(): string | undefined;
    private _postalCode?;
    get postalCode(): string;
    set postalCode(value: string);
    resetPostalCode(): void;
    get postalCodeInput(): string | undefined;
    private _province?;
    get province(): string;
    set province(value: string);
    resetProvince(): void;
    get provinceInput(): string | undefined;
    private _serialNumber?;
    get serialNumber(): string;
    set serialNumber(value: string);
    resetSerialNumber(): void;
    get serialNumberInput(): string | undefined;
    private _streetAddress?;
    get streetAddress(): string[];
    set streetAddress(value: string[]);
    resetStreetAddress(): void;
    get streetAddressInput(): string[] | undefined;
}
export declare class CertRequestSubjectList extends cdktn.ComplexList {
    internalValue?: CertRequestSubject[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CertRequestSubjectOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request tls_cert_request}
*/
export declare class CertRequest extends cdktn.TerraformResource {
    static readonly tfResourceType = "tls_cert_request";
    /**
    * Generates CDKTN code for importing a CertRequest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CertRequest to import
    * @param importFromId The id of the existing CertRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CertRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/cert_request tls_cert_request} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CertRequestConfig
    */
    constructor(scope: Construct, id: string, config: CertRequestConfig);
    get certRequestPem(): string;
    private _dnsNames?;
    get dnsNames(): string[];
    set dnsNames(value: string[]);
    resetDnsNames(): void;
    get dnsNamesInput(): string[] | undefined;
    get id(): string;
    private _ipAddresses?;
    get ipAddresses(): string[];
    set ipAddresses(value: string[]);
    resetIpAddresses(): void;
    get ipAddressesInput(): string[] | undefined;
    get keyAlgorithm(): string;
    private _privateKeyPem?;
    get privateKeyPem(): string;
    set privateKeyPem(value: string);
    get privateKeyPemInput(): string | undefined;
    private _uris?;
    get uris(): string[];
    set uris(value: string[]);
    resetUris(): void;
    get urisInput(): string[] | undefined;
    private _subject;
    get subject(): CertRequestSubjectList;
    putSubject(value: CertRequestSubject[] | cdktn.IResolvable): void;
    resetSubject(): void;
    get subjectInput(): cdktn.IResolvable | CertRequestSubject[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
