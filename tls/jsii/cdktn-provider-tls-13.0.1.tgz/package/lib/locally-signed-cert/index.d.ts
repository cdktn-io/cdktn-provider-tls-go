/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LocallySignedCertConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of key usages allowed for the issued certificate. Values are defined in [RFC 5280](https://datatracker.ietf.org/doc/html/rfc5280) and combine flags defined by both [Key Usages](https://datatracker.ietf.org/doc/html/rfc5280#section-4.2.1.3) and [Extended Key Usages](https://datatracker.ietf.org/doc/html/rfc5280#section-4.2.1.12). Accepted values: `any_extended`, `cert_signing`, `client_auth`, `code_signing`, `content_commitment`, `crl_signing`, `data_encipherment`, `decipher_only`, `digital_signature`, `email_protection`, `encipher_only`, `ipsec_end_system`, `ipsec_tunnel`, `ipsec_user`, `key_agreement`, `key_encipherment`, `microsoft_commercial_code_signing`, `microsoft_kernel_code_signing`, `microsoft_server_gated_crypto`, `netscape_server_gated_crypto`, `ocsp_signing`, `server_auth`, `timestamping`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#allowed_uses LocallySignedCert#allowed_uses}
    */
    readonly allowedUses: string[];
    /**
    * Certificate data of the Certificate Authority (CA) in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#ca_cert_pem LocallySignedCert#ca_cert_pem}
    */
    readonly caCertPem: string;
    /**
    * Private key of the Certificate Authority (CA) used to sign the certificate, in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#ca_private_key_pem LocallySignedCert#ca_private_key_pem}
    */
    readonly caPrivateKeyPem: string;
    /**
    * Certificate request data in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#cert_request_pem LocallySignedCert#cert_request_pem}
    */
    readonly certRequestPem: string;
    /**
    * The resource will consider the certificate to have expired the given number of hours before its actual expiry time. This can be useful to deploy an updated certificate in advance of the expiration of the current certificate. However, the old certificate remains valid until its true expiration time, since this resource does not (and cannot) support certificate revocation. Also, this advance update can only be performed should the Terraform configuration be applied during the early renewal period. (default: `0`)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#early_renewal_hours LocallySignedCert#early_renewal_hours}
    */
    readonly earlyRenewalHours?: number;
    /**
    * Is the generated certificate representing a Certificate Authority (CA) (default: `false`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#is_ca_certificate LocallySignedCert#is_ca_certificate}
    */
    readonly isCaCertificate?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of intermediate certificates that may follow this certificate in a valid certification path. If `is_ca_certificate` is `false`, this value is ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#max_path_length LocallySignedCert#max_path_length}
    */
    readonly maxPathLength?: number;
    /**
    * Should the generated certificate include a [subject key identifier](https://datatracker.ietf.org/doc/html/rfc5280#section-4.2.1.2) (default: `false`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#set_subject_key_id LocallySignedCert#set_subject_key_id}
    */
    readonly setSubjectKeyId?: boolean | cdktn.IResolvable;
    /**
    * Number of hours, after initial issuing, that the certificate will remain valid for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#validity_period_hours LocallySignedCert#validity_period_hours}
    */
    readonly validityPeriodHours: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert tls_locally_signed_cert}
*/
export declare class LocallySignedCert extends cdktn.TerraformResource {
    static readonly tfResourceType = "tls_locally_signed_cert";
    /**
    * Generates CDKTN code for importing a LocallySignedCert resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LocallySignedCert to import
    * @param importFromId The id of the existing LocallySignedCert that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LocallySignedCert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/locally_signed_cert tls_locally_signed_cert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LocallySignedCertConfig
    */
    constructor(scope: Construct, id: string, config: LocallySignedCertConfig);
    private _allowedUses?;
    get allowedUses(): string[];
    set allowedUses(value: string[]);
    get allowedUsesInput(): string[] | undefined;
    private _caCertPem?;
    get caCertPem(): string;
    set caCertPem(value: string);
    get caCertPemInput(): string | undefined;
    get caKeyAlgorithm(): string;
    private _caPrivateKeyPem?;
    get caPrivateKeyPem(): string;
    set caPrivateKeyPem(value: string);
    get caPrivateKeyPemInput(): string | undefined;
    get certPem(): string;
    private _certRequestPem?;
    get certRequestPem(): string;
    set certRequestPem(value: string);
    get certRequestPemInput(): string | undefined;
    private _earlyRenewalHours?;
    get earlyRenewalHours(): number;
    set earlyRenewalHours(value: number);
    resetEarlyRenewalHours(): void;
    get earlyRenewalHoursInput(): number | undefined;
    get id(): string;
    private _isCaCertificate?;
    get isCaCertificate(): boolean | cdktn.IResolvable;
    set isCaCertificate(value: boolean | cdktn.IResolvable);
    resetIsCaCertificate(): void;
    get isCaCertificateInput(): boolean | cdktn.IResolvable | undefined;
    private _maxPathLength?;
    get maxPathLength(): number;
    set maxPathLength(value: number);
    resetMaxPathLength(): void;
    get maxPathLengthInput(): number | undefined;
    get readyForRenewal(): cdktn.IResolvable;
    private _setSubjectKeyId?;
    get setSubjectKeyId(): boolean | cdktn.IResolvable;
    set setSubjectKeyId(value: boolean | cdktn.IResolvable);
    resetSetSubjectKeyId(): void;
    get setSubjectKeyIdInput(): boolean | cdktn.IResolvable | undefined;
    get validityEndTime(): string;
    private _validityPeriodHours?;
    get validityPeriodHours(): number;
    set validityPeriodHours(value: number);
    get validityPeriodHoursInput(): number | undefined;
    get validityStartTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
