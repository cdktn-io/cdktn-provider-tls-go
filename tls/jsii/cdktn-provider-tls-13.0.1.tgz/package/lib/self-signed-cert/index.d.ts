/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SelfSignedCertConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of key usages allowed for the issued certificate. Values are defined in [RFC 5280](https://datatracker.ietf.org/doc/html/rfc5280) and combine flags defined by both [Key Usages](https://datatracker.ietf.org/doc/html/rfc5280#section-4.2.1.3) and [Extended Key Usages](https://datatracker.ietf.org/doc/html/rfc5280#section-4.2.1.12). Accepted values: `any_extended`, `cert_signing`, `client_auth`, `code_signing`, `content_commitment`, `crl_signing`, `data_encipherment`, `decipher_only`, `digital_signature`, `email_protection`, `encipher_only`, `ipsec_end_system`, `ipsec_tunnel`, `ipsec_user`, `key_agreement`, `key_encipherment`, `microsoft_commercial_code_signing`, `microsoft_kernel_code_signing`, `microsoft_server_gated_crypto`, `netscape_server_gated_crypto`, `ocsp_signing`, `server_auth`, `timestamping`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#allowed_uses SelfSignedCert#allowed_uses}
    */
    readonly allowedUses: string[];
    /**
    * List of DNS names for which a certificate is being requested (i.e. certificate subjects).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#dns_names SelfSignedCert#dns_names}
    */
    readonly dnsNames?: string[];
    /**
    * The resource will consider the certificate to have expired the given number of hours before its actual expiry time. This can be useful to deploy an updated certificate in advance of the expiration of the current certificate. However, the old certificate remains valid until its true expiration time, since this resource does not (and cannot) support certificate revocation. Also, this advance update can only be performed should the Terraform configuration be applied during the early renewal period. (default: `0`)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#early_renewal_hours SelfSignedCert#early_renewal_hours}
    */
    readonly earlyRenewalHours?: number;
    /**
    * List of IP addresses for which a certificate is being requested (i.e. certificate subjects).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#ip_addresses SelfSignedCert#ip_addresses}
    */
    readonly ipAddresses?: string[];
    /**
    * Is the generated certificate representing a Certificate Authority (CA) (default: `false`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#is_ca_certificate SelfSignedCert#is_ca_certificate}
    */
    readonly isCaCertificate?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of intermediate certificates that may follow this certificate in a valid certification path. If `is_ca_certificate` is `false`, this value is ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#max_path_length SelfSignedCert#max_path_length}
    */
    readonly maxPathLength?: number;
    /**
    * Private key in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format, that the certificate will belong to. This can be read from a separate file using the [`file`](https://www.terraform.io/language/functions/file) interpolation function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#private_key_pem SelfSignedCert#private_key_pem}
    */
    readonly privateKeyPem: string;
    /**
    * Should the generated certificate include an [authority key identifier](https://datatracker.ietf.org/doc/html/rfc5280#section-4.2.1.1): for self-signed certificates this is the same value as the [subject key identifier](https://datatracker.ietf.org/doc/html/rfc5280#section-4.2.1.2) (default: `false`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#set_authority_key_id SelfSignedCert#set_authority_key_id}
    */
    readonly setAuthorityKeyId?: boolean | cdktn.IResolvable;
    /**
    * Should the generated certificate include a [subject key identifier](https://datatracker.ietf.org/doc/html/rfc5280#section-4.2.1.2) (default: `false`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#set_subject_key_id SelfSignedCert#set_subject_key_id}
    */
    readonly setSubjectKeyId?: boolean | cdktn.IResolvable;
    /**
    * List of URIs for which a certificate is being requested (i.e. certificate subjects).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#uris SelfSignedCert#uris}
    */
    readonly uris?: string[];
    /**
    * Number of hours, after initial issuing, that the certificate will remain valid for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#validity_period_hours SelfSignedCert#validity_period_hours}
    */
    readonly validityPeriodHours: number;
    /**
    * subject block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#subject SelfSignedCert#subject}
    */
    readonly subject?: SelfSignedCertSubject[] | cdktn.IResolvable;
}
export interface SelfSignedCertSubject {
    /**
    * Distinguished name: `CN`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#common_name SelfSignedCert#common_name}
    */
    readonly commonName?: string;
    /**
    * Distinguished name: `C`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#country SelfSignedCert#country}
    */
    readonly country?: string;
    /**
    * ASN.1 Object Identifier (OID): `1.2.840.113549.1.9.1`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#email_address SelfSignedCert#email_address}
    */
    readonly emailAddress?: string;
    /**
    * Distinguished name: `L`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#locality SelfSignedCert#locality}
    */
    readonly locality?: string;
    /**
    * Distinguished name: `O`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#organization SelfSignedCert#organization}
    */
    readonly organization?: string;
    /**
    * Distinguished name: `OU`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#organizational_unit SelfSignedCert#organizational_unit}
    */
    readonly organizationalUnit?: string;
    /**
    * Distinguished name: `PC`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#postal_code SelfSignedCert#postal_code}
    */
    readonly postalCode?: string;
    /**
    * Distinguished name: `ST`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#province SelfSignedCert#province}
    */
    readonly province?: string;
    /**
    * Distinguished name: `SERIALNUMBER`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#serial_number SelfSignedCert#serial_number}
    */
    readonly serialNumber?: string;
    /**
    * Distinguished name: `STREET`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#street_address SelfSignedCert#street_address}
    */
    readonly streetAddress?: string[];
}
export declare function selfSignedCertSubjectToTerraform(struct?: SelfSignedCertSubject | cdktn.IResolvable): any;
export declare function selfSignedCertSubjectToHclTerraform(struct?: SelfSignedCertSubject | cdktn.IResolvable): any;
export declare class SelfSignedCertSubjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SelfSignedCertSubject | cdktn.IResolvable | undefined;
    set internalValue(value: SelfSignedCertSubject | cdktn.IResolvable | undefined);
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    resetCommonName(): void;
    get commonNameInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    resetCountry(): void;
    get countryInput(): string | undefined;
    private _emailAddress?;
    get emailAddress(): string;
    set emailAddress(value: string);
    resetEmailAddress(): void;
    get emailAddressInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    resetLocality(): void;
    get localityInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _organizationalUnit?;
    get organizationalUnit(): string;
    set organizationalUnit(value: string);
    resetOrganizationalUnit(): void;
    get organizationalUnitInput(): string | undefined;
    private _postalCode?;
    get postalCode(): string;
    set postalCode(value: string);
    resetPostalCode(): void;
    get postalCodeInput(): string | undefined;
    private _province?;
    get province(): string;
    set province(value: string);
    resetProvince(): void;
    get provinceInput(): string | undefined;
    private _serialNumber?;
    get serialNumber(): string;
    set serialNumber(value: string);
    resetSerialNumber(): void;
    get serialNumberInput(): string | undefined;
    private _streetAddress?;
    get streetAddress(): string[];
    set streetAddress(value: string[]);
    resetStreetAddress(): void;
    get streetAddressInput(): string[] | undefined;
}
export declare class SelfSignedCertSubjectList extends cdktn.ComplexList {
    internalValue?: SelfSignedCertSubject[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SelfSignedCertSubjectOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert tls_self_signed_cert}
*/
export declare class SelfSignedCert extends cdktn.TerraformResource {
    static readonly tfResourceType = "tls_self_signed_cert";
    /**
    * Generates CDKTN code for importing a SelfSignedCert resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SelfSignedCert to import
    * @param importFromId The id of the existing SelfSignedCert that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SelfSignedCert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tls/4.2.1/docs/resources/self_signed_cert tls_self_signed_cert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SelfSignedCertConfig
    */
    constructor(scope: Construct, id: string, config: SelfSignedCertConfig);
    private _allowedUses?;
    get allowedUses(): string[];
    set allowedUses(value: string[]);
    get allowedUsesInput(): string[] | undefined;
    get certPem(): string;
    private _dnsNames?;
    get dnsNames(): string[];
    set dnsNames(value: string[]);
    resetDnsNames(): void;
    get dnsNamesInput(): string[] | undefined;
    private _earlyRenewalHours?;
    get earlyRenewalHours(): number;
    set earlyRenewalHours(value: number);
    resetEarlyRenewalHours(): void;
    get earlyRenewalHoursInput(): number | undefined;
    get id(): string;
    private _ipAddresses?;
    get ipAddresses(): string[];
    set ipAddresses(value: string[]);
    resetIpAddresses(): void;
    get ipAddressesInput(): string[] | undefined;
    private _isCaCertificate?;
    get isCaCertificate(): boolean | cdktn.IResolvable;
    set isCaCertificate(value: boolean | cdktn.IResolvable);
    resetIsCaCertificate(): void;
    get isCaCertificateInput(): boolean | cdktn.IResolvable | undefined;
    get keyAlgorithm(): string;
    private _maxPathLength?;
    get maxPathLength(): number;
    set maxPathLength(value: number);
    resetMaxPathLength(): void;
    get maxPathLengthInput(): number | undefined;
    private _privateKeyPem?;
    get privateKeyPem(): string;
    set privateKeyPem(value: string);
    get privateKeyPemInput(): string | undefined;
    get readyForRenewal(): cdktn.IResolvable;
    private _setAuthorityKeyId?;
    get setAuthorityKeyId(): boolean | cdktn.IResolvable;
    set setAuthorityKeyId(value: boolean | cdktn.IResolvable);
    resetSetAuthorityKeyId(): void;
    get setAuthorityKeyIdInput(): boolean | cdktn.IResolvable | undefined;
    private _setSubjectKeyId?;
    get setSubjectKeyId(): boolean | cdktn.IResolvable;
    set setSubjectKeyId(value: boolean | cdktn.IResolvable);
    resetSetSubjectKeyId(): void;
    get setSubjectKeyIdInput(): boolean | cdktn.IResolvable | undefined;
    private _uris?;
    get uris(): string[];
    set uris(value: string[]);
    resetUris(): void;
    get urisInput(): string[] | undefined;
    get validityEndTime(): string;
    private _validityPeriodHours?;
    get validityPeriodHours(): number;
    set validityPeriodHours(value: number);
    get validityPeriodHoursInput(): number | undefined;
    get validityStartTime(): string;
    private _subject;
    get subject(): SelfSignedCertSubjectList;
    putSubject(value: SelfSignedCertSubject[] | cdktn.IResolvable): void;
    resetSubject(): void;
    get subjectInput(): cdktn.IResolvable | SelfSignedCertSubject[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
