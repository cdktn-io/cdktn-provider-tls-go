/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralTlsPrivateKeyConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Name of the algorithm to use when generating the private key. Currently-supported values are: `RSA`, `ECDSA`, `ED25519`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/ephemeral-resources/private_key#algorithm EphemeralTlsPrivateKey#algorithm}
    */
    readonly algorithm: string;
    /**
    * When `algorithm` is `ECDSA`, the name of the elliptic curve to use. Currently-supported values are: `P224`, `P256`, `P384`, `P521`. (default: `P224`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/ephemeral-resources/private_key#ecdsa_curve EphemeralTlsPrivateKey#ecdsa_curve}
    */
    readonly ecdsaCurve?: string;
    /**
    * When `algorithm` is `RSA`, the size of the generated RSA key, in bits (default: `2048`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/ephemeral-resources/private_key#rsa_bits EphemeralTlsPrivateKey#rsa_bits}
    */
    readonly rsaBits?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/ephemeral-resources/private_key tls_private_key}
*/
export declare class EphemeralTlsPrivateKey extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "tls_private_key";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/ephemeral-resources/private_key tls_private_key} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralTlsPrivateKeyConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralTlsPrivateKeyConfig);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    get algorithmInput(): string | undefined;
    private _ecdsaCurve?;
    get ecdsaCurve(): string;
    set ecdsaCurve(value: string);
    resetEcdsaCurve(): void;
    get ecdsaCurveInput(): string | undefined;
    get privateKeyOpenssh(): string;
    get privateKeyPem(): string;
    get privateKeyPemPkcs8(): string;
    get publicKeyFingerprintMd5(): string;
    get publicKeyFingerprintSha256(): string;
    get publicKeyOpenssh(): string;
    get publicKeyPem(): string;
    private _rsaBits?;
    get rsaBits(): number;
    set rsaBits(value: number);
    resetRsaBits(): void;
    get rsaBitsInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
