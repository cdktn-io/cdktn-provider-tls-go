/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TlsProviderConfig {
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs#alias TlsProvider#alias}
    */
    readonly alias?: string;
    /**
    * proxy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs#proxy TlsProvider#proxy}
    */
    readonly proxy?: TlsProviderProxy[] | cdktn.IResolvable;
}
export interface TlsProviderProxy {
    /**
    * When `true` the provider will discover the proxy configuration from environment variables. This is based upon [`http.ProxyFromEnvironment`](https://pkg.go.dev/net/http#ProxyFromEnvironment) and it supports the same environment variables (default: `true`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs#from_env TlsProvider#from_env}
    */
    readonly fromEnv?: boolean | cdktn.IResolvable;
    /**
    * Password used for Basic authentication against the Proxy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs#password TlsProvider#password}
    */
    readonly password?: string;
    /**
    * URL used to connect to the Proxy. Accepted schemes are: `http`, `https`, `socks5`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs#url TlsProvider#url}
    */
    readonly url?: string;
    /**
    * Username (or Token) used for Basic authentication against the Proxy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs#username TlsProvider#username}
    */
    readonly username?: string;
}
export declare function tlsProviderProxyToTerraform(struct?: TlsProviderProxy | cdktn.IResolvable): any;
export declare function tlsProviderProxyToHclTerraform(struct?: TlsProviderProxy | cdktn.IResolvable): any;
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs tls}
*/
export declare class TlsProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "tls";
    /**
    * Generates CDKTN code for importing a TlsProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TlsProvider to import
    * @param importFromId The id of the existing TlsProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TlsProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs tls} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TlsProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TlsProviderConfig);
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _proxy?;
    get proxy(): TlsProviderProxy[] | cdktn.IResolvable | undefined;
    set proxy(value: TlsProviderProxy[] | cdktn.IResolvable | undefined);
    resetProxy(): void;
    get proxyInput(): cdktn.IResolvable | TlsProviderProxy[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
