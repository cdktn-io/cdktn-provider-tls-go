/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PrivateKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the algorithm to use when generating the private key. Currently-supported values are: `RSA`, `ECDSA`, `ED25519`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/resources/private_key#algorithm PrivateKey#algorithm}
    */
    readonly algorithm: string;
    /**
    * When `algorithm` is `ECDSA`, the name of the elliptic curve to use. Currently-supported values are: `P224`, `P256`, `P384`, `P521`. (default: `P224`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/resources/private_key#ecdsa_curve PrivateKey#ecdsa_curve}
    */
    readonly ecdsaCurve?: string;
    /**
    * When `algorithm` is `RSA`, the size of the generated RSA key, in bits (default: `2048`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/resources/private_key#rsa_bits PrivateKey#rsa_bits}
    */
    readonly rsaBits?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/resources/private_key tls_private_key}
*/
export declare class PrivateKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "tls_private_key";
    /**
    * Generates CDKTN code for importing a PrivateKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PrivateKey to import
    * @param importFromId The id of the existing PrivateKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/resources/private_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PrivateKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/resources/private_key tls_private_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PrivateKeyConfig
    */
    constructor(scope: Construct, id: string, config: PrivateKeyConfig);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    get algorithmInput(): string | undefined;
    private _ecdsaCurve?;
    get ecdsaCurve(): string;
    set ecdsaCurve(value: string);
    resetEcdsaCurve(): void;
    get ecdsaCurveInput(): string | undefined;
    get id(): string;
    get privateKeyOpenssh(): string;
    get privateKeyPem(): string;
    get privateKeyPemPkcs8(): string;
    get publicKeyFingerprintMd5(): string;
    get publicKeyFingerprintSha256(): string;
    get publicKeyOpenssh(): string;
    get publicKeyPem(): string;
    private _rsaBits?;
    get rsaBits(): number;
    set rsaBits(value: number);
    resetRsaBits(): void;
    get rsaBitsInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
