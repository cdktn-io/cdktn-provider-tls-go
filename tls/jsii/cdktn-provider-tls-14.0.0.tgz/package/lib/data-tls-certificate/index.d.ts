/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTlsCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The content of the certificate in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/data-sources/certificate#content DataTlsCertificate#content}
    */
    readonly content?: string;
    /**
    * URL of the endpoint to get the certificates from. Accepted schemes are: `https`, `tls`. For scheme `https://` it will use the HTTP protocol and apply the `proxy` configuration of the provider, if set. For scheme `tls://` it will instead use a secure TCP socket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/data-sources/certificate#url DataTlsCertificate#url}
    */
    readonly url?: string;
    /**
    * Whether to verify the certificate chain while parsing it or not (default: `true`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/data-sources/certificate#verify_chain DataTlsCertificate#verify_chain}
    */
    readonly verifyChain?: boolean | cdktn.IResolvable;
}
export interface DataTlsCertificateCertificates {
}
export declare function dataTlsCertificateCertificatesToTerraform(struct?: DataTlsCertificateCertificates): any;
export declare function dataTlsCertificateCertificatesToHclTerraform(struct?: DataTlsCertificateCertificates): any;
export declare class DataTlsCertificateCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTlsCertificateCertificates | undefined;
    set internalValue(value: DataTlsCertificateCertificates | undefined);
    get certPem(): string;
    get isCa(): cdktn.IResolvable;
    get issuer(): string;
    get maxPathLength(): number;
    get notAfter(): string;
    get notBefore(): string;
    get publicKeyAlgorithm(): string;
    get serialNumber(): string;
    get sha1Fingerprint(): string;
    get signatureAlgorithm(): string;
    get subject(): string;
    get version(): number;
}
export declare class DataTlsCertificateCertificatesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTlsCertificateCertificatesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/data-sources/certificate tls_certificate}
*/
export declare class DataTlsCertificate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tls_certificate";
    /**
    * Generates CDKTN code for importing a DataTlsCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTlsCertificate to import
    * @param importFromId The id of the existing DataTlsCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/data-sources/certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTlsCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tls/4.3.0/docs/data-sources/certificate tls_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTlsCertificateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTlsCertificateConfig);
    private _certificates;
    get certificates(): DataTlsCertificateCertificatesList;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    get id(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _verifyChain?;
    get verifyChain(): boolean | cdktn.IResolvable;
    set verifyChain(value: boolean | cdktn.IResolvable);
    resetVerifyChain(): void;
    get verifyChainInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
