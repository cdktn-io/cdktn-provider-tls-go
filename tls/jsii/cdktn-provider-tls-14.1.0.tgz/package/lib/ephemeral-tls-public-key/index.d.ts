/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralTlsPublicKeyConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * The private key (in  [OpenSSH PEM (RFC 4716)](https://datatracker.ietf.org/doc/html/rfc4716) format) to extract the public key from. This is _mutually exclusive_ with `private_key_pem`. Currently-supported algorithms for keys are: `RSA`, `ECDSA`, `ED25519`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.4.0/docs/ephemeral-resources/public_key#private_key_openssh EphemeralTlsPublicKey#private_key_openssh}
    */
    readonly privateKeyOpenssh?: string;
    /**
    * The private key (in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format) to extract the public key from. This is _mutually exclusive_ with `private_key_openssh`. Currently-supported algorithms for keys are: `RSA`, `ECDSA`, `ED25519`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/tls/4.4.0/docs/ephemeral-resources/public_key#private_key_pem EphemeralTlsPublicKey#private_key_pem}
    */
    readonly privateKeyPem?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/tls/4.4.0/docs/ephemeral-resources/public_key tls_public_key}
*/
export declare class EphemeralTlsPublicKey extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "tls_public_key";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/tls/4.4.0/docs/ephemeral-resources/public_key tls_public_key} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralTlsPublicKeyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: EphemeralTlsPublicKeyConfig);
    get algorithm(): string;
    get id(): string;
    private _privateKeyOpenssh?;
    get privateKeyOpenssh(): string;
    set privateKeyOpenssh(value: string);
    resetPrivateKeyOpenssh(): void;
    get privateKeyOpensshInput(): string | undefined;
    private _privateKeyPem?;
    get privateKeyPem(): string;
    set privateKeyPem(value: string);
    resetPrivateKeyPem(): void;
    get privateKeyPemInput(): string | undefined;
    get publicKeyFingerprintMd5(): string;
    get publicKeyFingerprintSha256(): string;
    get publicKeyOpenssh(): string;
    get publicKeyPem(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
